import myJson from './data.json'
function Table(){
  const Data=myJson.map((i)=>{
    return(
      <tr>
        <td style={{border:"1px solid black"}}>{i.ID}</td>
        <td style={{border:"1px solid black"}}>{i.Product_Name}</td>
        <td style={{border:"1px solid black"}}>{i.Quantity}</td>
        <td style={{border:"1px solid black"}}>{i.Price}</td>
      </tr>
    )
  })
  return <>
  <h2>Product List</h2>
  <table style={{border:"1px solid black"}}>
    <thead>
      <tr >
        <th style={{border:"1px solid black"}}>ID</th>
        <th style={{border:"1px solid black"}}>Product Name</th>
        <th style={{border:"1px solid black"}}>Quantity</th>
        <th style={{border:"1px solid black"}}>Price</th>
      </tr>
    </thead>
    <tbody>
      {Data}
    </tbody>
  </table>
  </>;
}
export default Table;
